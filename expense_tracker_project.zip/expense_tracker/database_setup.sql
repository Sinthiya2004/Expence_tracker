-- ============================================
-- Expense Tracker - MySQL Database Setup
-- Run this in MySQL before starting Django
-- ============================================

-- 1. Create the database
CREATE DATABASE IF NOT EXISTS expense_tracker_db
  CHARACTER SET utf8mb4
  COLLATE utf8mb4_unicode_ci;

USE expense_tracker_db;

-- ============================================
-- NOTE: Django will auto-create these tables
-- via migrations (python manage.py migrate)
-- This file shows the SQL structure for reference
-- ============================================

-- Users table (created by Django auth)
-- CREATE TABLE auth_user (
--   id            INT AUTO_INCREMENT PRIMARY KEY,
--   username      VARCHAR(150) UNIQUE NOT NULL,
--   email         VARCHAR(254),
--   password      VARCHAR(128) NOT NULL,
--   first_name    VARCHAR(150),
--   last_name     VARCHAR(150),
--   is_active     TINYINT(1) DEFAULT 1,
--   date_joined   DATETIME NOT NULL
-- );

-- Expenses table (created by Django migrations)
-- CREATE TABLE tracker_expense (
--   id          INT AUTO_INCREMENT PRIMARY KEY,
--   user_id     INT NOT NULL,
--   title       VARCHAR(200) NOT NULL,
--   amount      DECIMAL(10,2) NOT NULL,
--   category    VARCHAR(50) NOT NULL,
--   date        DATE NOT NULL,
--   note        LONGTEXT,
--   created_at  DATETIME(6) NOT NULL,
--   FOREIGN KEY (user_id) REFERENCES auth_user(id) ON DELETE CASCADE
-- );

-- ============================================
-- Useful SQL queries for the project
-- ============================================

-- Total expenses per category for a user:
-- SELECT category, SUM(amount) as total
-- FROM tracker_expense
-- WHERE user_id = 1
-- GROUP BY category
-- ORDER BY total DESC;

-- Monthly summary:
-- SELECT YEAR(date) as yr, MONTH(date) as mo, SUM(amount) as total
-- FROM tracker_expense
-- WHERE user_id = 1
-- GROUP BY yr, mo
-- ORDER BY yr DESC, mo DESC;

-- Top 5 biggest expenses:
-- SELECT title, amount, category, date
-- FROM tracker_expense
-- WHERE user_id = 1
-- ORDER BY amount DESC
-- LIMIT 5;
