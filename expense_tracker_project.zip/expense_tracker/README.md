# 💰 Smart Expense Tracker

Full-stack web app built with **HTML, CSS, JavaScript, Python (Django), SQL (MySQL)**

---

## 🛠️ Tech Stack

| Layer    | Technology       |
|----------|-----------------|
| Frontend | HTML + CSS + JS  |
| Backend  | Python + Django  |
| Database | MySQL (SQL)      |
| Charts   | Chart.js (CDN)   |

---

## 📁 Project Structure

```
expense_tracker/
├── manage.py
├── requirements.txt
├── database_setup.sql
│
├── expense_tracker/          ← Django project config
│   ├── settings.py
│   ├── urls.py
│   └── wsgi.py
│
└── tracker/                  ← Main app
    ├── models.py             ← Database model (Expense)
    ├── views.py              ← All logic (login, CRUD, charts)
    ├── forms.py              ← Django forms
    ├── urls.py               ← URL routes
    │
    ├── templates/tracker/
    │   ├── login.html
    │   ├── register.html
    │   ├── dashboard.html    ← Main page (charts + table)
    │   └── edit.html
    │
    └── static/
        ├── css/style.css     ← Dark gold theme
        └── js/script.js      ← Chart.js charts
```

---

## ⚙️ Setup Steps

### 1. Install Python packages
```bash
pip install -r requirements.txt
```

### 2. Create MySQL Database
Open MySQL and run:
```sql
CREATE DATABASE expense_tracker_db;
```

### 3. Update settings.py
Edit `expense_tracker/settings.py` — change MySQL password:
```python
DATABASES = {
    'default': {
        'ENGINE': 'django.db.backends.mysql',
        'NAME': 'expense_tracker_db',
        'USER': 'root',
        'PASSWORD': 'YOUR_MYSQL_PASSWORD',  # ← change this
        'HOST': 'localhost',
        'PORT': '3306',
    }
}
```

### 4. Run Django migrations (creates all tables)
```bash
python manage.py makemigrations
python manage.py migrate
```

### 5. Start the server
```bash
python manage.py runserver
```

### 6. Open in browser
```
http://127.0.0.1:8000/
```

---

## ✨ Features

- ✅ User Register / Login / Logout
- ✅ Add / Edit / Delete Expenses
- ✅ Category filter (Food, Travel, Bills, etc.)
- ✅ Month-wise filter
- ✅ Pie chart — category breakdown
- ✅ Bar chart — last 6 months trend
- ✅ Summary cards (monthly total, all-time total, count)
- ✅ Responsive design (mobile friendly)
- ✅ Dark theme with gold accents

---

## 🎤 Interview Points

> "I built a full-stack expense tracker using Django (Python) as the backend framework,
> MySQL for relational data storage with proper foreign key relationships,
> and vanilla JavaScript with Chart.js for dynamic pie and bar chart visualizations.
> The app supports full CRUD operations, user authentication using Django's built-in auth system,
> and a REST-style JSON API endpoint for client-side data fetching."
