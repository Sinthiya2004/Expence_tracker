from django.db import models
from django.contrib.auth.models import User

CATEGORY_CHOICES = [
    ('Food', '🍔 Food'),
    ('Travel', '🚗 Travel'),
    ('Bills', '💡 Bills'),
    ('Shopping', '🛍️ Shopping'),
    ('Health', '💊 Health'),
    ('Education', '📚 Education'),
    ('Entertainment', '🎬 Entertainment'),
    ('Other', '📦 Other'),
]

class Expense(models.Model):
    user       = models.ForeignKey(User, on_delete=models.CASCADE)
    title      = models.CharField(max_length=200)
    amount     = models.DecimalField(max_digits=10, decimal_places=2)
    category   = models.CharField(max_length=50, choices=CATEGORY_CHOICES)
    date       = models.DateField()
    note       = models.TextField(blank=True, null=True)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ['-date', '-created_at']

    def __str__(self):
        return f"{self.title} - ₹{self.amount}"
