// ── Chart Colors ────────────────────────────────────────
const COLORS = [
  '#f5c518', '#e05260', '#2eb87e', '#6c8ef5',
  '#f5a623', '#a855f7', '#22d3ee', '#fb7185'
];

// ── Pie Chart: Category Breakdown ───────────────────────
function renderPieChart() {
  const canvas = document.getElementById('pieChart');
  if (!canvas || !CAT_DATA || CAT_DATA.length === 0) {
    if (canvas) {
      canvas.parentElement.innerHTML += '<p style="color:#8b90a8;text-align:center;padding:20px">No data for this month</p>';
      canvas.remove();
    }
    return;
  }

  const labels  = CAT_DATA.map(d => d.category);
  const amounts = CAT_DATA.map(d => parseFloat(d.total));

  new Chart(canvas, {
    type: 'doughnut',
    data: {
      labels,
      datasets: [{
        data: amounts,
        backgroundColor: COLORS,
        borderColor: '#1a1d27',
        borderWidth: 3,
        hoverOffset: 8,
      }]
    },
    options: {
      responsive: true,
      plugins: {
        legend: {
          position: 'bottom',
          labels: {
            color: '#8b90a8',
            padding: 12,
            font: { size: 12 }
          }
        },
        tooltip: {
          callbacks: {
            label: ctx => ` ₹${ctx.parsed.toLocaleString('en-IN')}`
          }
        }
      }
    }
  });
}

// ── Bar Chart: Monthly Trend ─────────────────────────────
function renderBarChart() {
  const canvas = document.getElementById('barChart');
  if (!canvas || !MONTHLY_DATA) return;

  const labels  = MONTHLY_DATA.map(d => d.label);
  const amounts = MONTHLY_DATA.map(d => d.amount);

  new Chart(canvas, {
    type: 'bar',
    data: {
      labels,
      datasets: [{
        label: 'Total Spent (₹)',
        data: amounts,
        backgroundColor: amounts.map((_, i) =>
          i === amounts.length - 1 ? '#f5c518' : '#2e3348'
        ),
        borderRadius: 6,
        borderSkipped: false,
      }]
    },
    options: {
      responsive: true,
      plugins: {
        legend: { display: false },
        tooltip: {
          callbacks: {
            label: ctx => ` ₹${ctx.parsed.y.toLocaleString('en-IN')}`
          }
        }
      },
      scales: {
        x: {
          ticks: { color: '#8b90a8', font: { size: 11 } },
          grid:  { color: '#2e3348' }
        },
        y: {
          ticks: {
            color: '#8b90a8',
            font: { size: 11 },
            callback: val => '₹' + val.toLocaleString('en-IN')
          },
          grid: { color: '#2e3348' }
        }
      }
    }
  });
}

// ── Auto-dismiss alerts ──────────────────────────────────
function autoDismissAlerts() {
  const alerts = document.querySelectorAll('.alert');
  alerts.forEach(alert => {
    setTimeout(() => {
      alert.style.transition = 'opacity 0.5s';
      alert.style.opacity = '0';
      setTimeout(() => alert.remove(), 500);
    }, 3000);
  });
}

// ── Set today's date on Add form ─────────────────────────
function setDefaultDate() {
  const dateInput = document.querySelector('input[name="date"]');
  if (dateInput && !dateInput.value) {
    const today = new Date().toISOString().split('T')[0];
    dateInput.value = today;
  }
}

// ── Init ─────────────────────────────────────────────────
document.addEventListener('DOMContentLoaded', () => {
  renderPieChart();
  renderBarChart();
  autoDismissAlerts();
  setDefaultDate();
});
