from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth import login, logout, authenticate
from django.contrib.auth.decorators import login_required
from django.contrib.auth.forms import AuthenticationForm
from django.contrib import messages
from django.http import JsonResponse
from django.db.models import Sum
from django.utils import timezone
import json
from datetime import date

from .models import Expense
from .forms import RegisterForm, ExpenseForm


# ─── Register ────────────────────────────────────────────────
def register_view(request):
    if request.user.is_authenticated:
        return redirect('dashboard')
    if request.method == 'POST':
        form = RegisterForm(request.POST)
        if form.is_valid():
            user = form.save()
            login(request, user)
            messages.success(request, f'Welcome {user.username}! Account created.')
            return redirect('dashboard')
    else:
        form = RegisterForm()
    return render(request, 'tracker/register.html', {'form': form})


# ─── Login ────────────────────────────────────────────────────
def login_view(request):
    if request.user.is_authenticated:
        return redirect('dashboard')
    if request.method == 'POST':
        form = AuthenticationForm(data=request.POST)
        if form.is_valid():
            user = form.get_user()
            login(request, user)
            return redirect('dashboard')
        else:
            messages.error(request, 'Invalid username or password.')
    else:
        form = AuthenticationForm()
    return render(request, 'tracker/login.html', {'form': form})


# ─── Logout ───────────────────────────────────────────────────
def logout_view(request):
    logout(request)
    return redirect('login')


# ─── Dashboard ────────────────────────────────────────────────
@login_required
def dashboard(request):
    today = date.today()
    expenses = Expense.objects.filter(user=request.user)

    # Month filter
    month = request.GET.get('month', today.strftime('%Y-%m'))
    year, mon = map(int, month.split('-'))
    filtered = expenses.filter(date__year=year, date__month=mon)

    # Summary cards
    total_month   = filtered.aggregate(Sum('amount'))['amount__sum'] or 0
    total_all     = expenses.aggregate(Sum('amount'))['amount__sum'] or 0
    expense_count = filtered.count()

    # Category breakdown for pie chart
    cat_data = (
        filtered.values('category')
                .annotate(total=Sum('amount'))
                .order_by('-total')
    )

    # Monthly trend (last 6 months) for bar chart
    monthly_data = []
    for i in range(5, -1, -1):
        m = today.month - i
        y = today.year
        while m <= 0:
            m += 12
            y -= 1
        amt = expenses.filter(date__year=y, date__month=m).aggregate(Sum('amount'))['amount__sum'] or 0
        monthly_data.append({
            'label': date(y, m, 1).strftime('%b %Y'),
            'amount': float(amt)
        })

    form = ExpenseForm()

    context = {
        'expenses'      : filtered,
        'form'          : form,
        'total_month'   : total_month,
        'total_all'     : total_all,
        'expense_count' : expense_count,
        'current_month' : month,
        'cat_data_json' : json.dumps(list(cat_data), default=str),
        'monthly_json'  : json.dumps(monthly_data),
    }
    return render(request, 'tracker/dashboard.html', context)


# ─── Add Expense ──────────────────────────────────────────────
@login_required
def add_expense(request):
    if request.method == 'POST':
        form = ExpenseForm(request.POST)
        if form.is_valid():
            expense = form.save(commit=False)
            expense.user = request.user
            expense.save()
            messages.success(request, 'Expense added!')
        else:
            messages.error(request, 'Please fix the errors.')
    return redirect('dashboard')


# ─── Edit Expense ─────────────────────────────────────────────
@login_required
def edit_expense(request, pk):
    expense = get_object_or_404(Expense, pk=pk, user=request.user)
    if request.method == 'POST':
        form = ExpenseForm(request.POST, instance=expense)
        if form.is_valid():
            form.save()
            messages.success(request, 'Expense updated!')
            return redirect('dashboard')
    else:
        form = ExpenseForm(instance=expense)
    return render(request, 'tracker/edit.html', {'form': form, 'expense': expense})


# ─── Delete Expense ───────────────────────────────────────────
@login_required
def delete_expense(request, pk):
    expense = get_object_or_404(Expense, pk=pk, user=request.user)
    if request.method == 'POST':
        expense.delete()
        messages.success(request, 'Expense deleted!')
    return redirect('dashboard')


# ─── API: expenses as JSON (for JS fetch) ────────────────────
@login_required
def api_expenses(request):
    expenses = Expense.objects.filter(user=request.user).values(
        'id', 'title', 'amount', 'category', 'date', 'note'
    )
    return JsonResponse({'expenses': list(expenses)}, safe=False)
